--Script de exclusão dos dados das tabelas

DROP TABLE supervisiona;
DROP TABLE Venda;
DROP TABLE Produto;
DROP TABLE Gerente;
DROP TABLE Empregado;